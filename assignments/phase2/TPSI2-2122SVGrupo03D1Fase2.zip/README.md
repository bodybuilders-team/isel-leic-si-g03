# isel-leic-si-2122sv-41d-group03

> Information Systems project of group 03 from LEIC41D class.

---

## Authors

- [André Páscoa](https://github.com/devandrepascoa)
- [André Jesus](https://github.com/Andre-J3sus)
- [Nyckollas Brandão](https://github.com/Nyckoka)

Professor: Eng. Walter Vieira

ISEL<br>
Bachelor in Computer Science and Computer Engineering<br>
Information Systems - LEIC41D - Group 03<br>
Summer Semester of 2021/2022